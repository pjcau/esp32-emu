ESPlay micro v2 case by PierreGG on Thingiverse: https://www.thingiverse.com/thing:5592683

Summary:
This is a case for ESPlay micro V2, an open source retrogame console based on ESP32 WROVER.Designed with Fusion360.Screen protector can be laser cutted in 3 mm (1/8") acrylic, svg file is provided.You'll need 4 15mm M3 screws.ESPlay micro project by Fuji Pebri can be found here : https://hackaday.io/project/166707-esplay-microEnjoy !